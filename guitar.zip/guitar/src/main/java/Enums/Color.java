package Enums;

public enum Color {

    WHITE("1"),
    BLACK("2"),
    RED("3"),
    YELLOW("4"),
    BLUE("5"),
    GREEN("6");

    public String id;

    Color(String id){
        this.id = id;
    }


}
