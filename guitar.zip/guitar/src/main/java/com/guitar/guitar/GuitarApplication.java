package com.guitar.guitar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuitarApplication {

	public static void main(String[] args) {
		SpringApplication.run(GuitarApplication.class, args);
	}

}
